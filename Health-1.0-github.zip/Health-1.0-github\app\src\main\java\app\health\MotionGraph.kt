package app.health

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import org.json.JSONArray

/** Actual sensor observations; no synthetic sleep phases. */
class MotionGraph(context: Context, binsIn: JSONArray?, private val color: Int) : View(context) {
    private val bins: JSONArray = binsIn ?: JSONArray()
    private val pen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bar = RectF()

    init {
        contentDescription = "Интенсивность движений за ночь, ${bins.length()} минутных интервалов"
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val total = bins.length()
        if (total == 0) return
        var max = .03
        for (i in 0 until total) max = Math.max(max, bins.optJSONObject(i).optDouble("motion", 0.0))
        val width = width / total.toFloat()
        pen.color = color
        for (i in 0 until total) {
            val bin = bins.optJSONObject(i)
            if (bin.optInt("samples") == 0) continue
            val height = Math.max(3f, (bin.optDouble("motion", 0.0) / max * (height - 12)).toFloat())
            bar.set(i * width + 1, getHeight() - height, i * width + Math.max(2f, width - 2), getHeight().toFloat())
            canvas.drawRoundRect(bar, 3f, 3f, pen)
        }
    }
}
